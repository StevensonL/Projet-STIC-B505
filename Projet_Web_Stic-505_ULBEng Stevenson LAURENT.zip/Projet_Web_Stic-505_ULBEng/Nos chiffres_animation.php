<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" NO_DATE="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<table>
    <thead>
    <tr>
        <th> <img src="dowload.png"> </th>
        <th> <h1> <strong> Animation </strong> </h1> </th>
    </tr>
    </thead>
</table>


<div>
    <table class="table table-striped" style="width: fit-content;">
        <thead class="table-dark">
            <tr>
                <th style="width: fit-content;">intitule</th>
                <th style="width: fit-content;">Nbres d'animation realisees</th>
            </tr>
        </thead>
        <tbody>


    <?php

    $pdo = new PDO("mysql:host:localhost;dbname=asblulbeng;charset=utf8", "root");
    $pdo->query("use asblulbeng");
    $consultQuery = $pdo->query(" select NO_DATE, count(NO_DATE) as NBR from animation group by INTITULE;");
    $results = $consultQuery->fetchAll();

    foreach ($results as $NO_DATE) {
        echo "<tr>";
            echo "<td>" . $NO_DATE["NO_DATE"] . "</td>";
            echo "<td>" . $NO_DATE["NBR"] . "</td>";
             echo "</tr>";
    }
    foreach ($results as $INTITULE) {
        echo "<tr>";
            echo "<td>" . $INTITULE["INTITULE"] . "</td>";
         echo "</tr>";
    }

    ?>

        </tbody>
    </table>
</div>


<div>
    <table class="table table-striped" style="width: fit-content;">
        <thead class="table-dark">
            <tr>
                <th>Statut</th> <!-- Pour connaitre le statut de l'ecole, actif ou pas @ parametrer -->
                <th>Nbres de Beneficiaires</th>
            </tr>
        </thead>
        <tbody>
    <?php

    $pdo = new PDO("mysql:host:localhost;dbname=asblulbeng;charset=utf8", "root");
    $pdo->query("use asblulbeng");
    $consultQuery = $pdo->query(" select NOM_ID, count(NOM_ID) as NBR from ecole group by NOM_ID;");
    $results = $consultQuery->fetchAll();

    foreach ($results as $nom_ecole) {
        echo "<tr>";
            echo "<td>" . $nom_ecole["STATUT"] . "</td>";
            echo "<td>" . $nom_ecole["NBR"] . "</td>";
        echo "</tr>";
    }

    ?>
        </tbody>
    </table>
</div>

<div>

    <table class="table table-striped" style="width: fit-content;">
        <thead class="table-dark">
            <tr>
                <th style="width: fit-content;">Projet</th>
                <th style="width: fit-content;">Animation</th>
                <th style="width: fit-content;">Nbres de volontaire</th>
            </tr>
        </thead>
        <tbody>


        <?php

        $pdo = new PDO("mysql:host:localhost;dbname=asblulbeng;charset=utf8", "root");
        $pdo->query("use asblulbeng");
        $consultQuery = $pdo->query("select v.MATRICULE, count(MATRICULE) as NBR 
                                    from volontaire v, animation a 
                                    where v.MATRICULE = a.MATRICULE_VOLTR
                                    group by INTITULE;");
        $results = $consultQuery->fetchAll();

        foreach ($results as $voltr) {
            echo "<tr>";
                echo "<td>" . $voltr["MATRICULE_VOLTR"] . "</td>";
                echo "<td>" . $voltr["INTITULE"] . "</td>";
                echo "<td>" . $voltr["NBR"] . "</td>";
            echo "</tr>";
        }

        ?>

        </tbody>
    </table>
</div>

</body>

</html>
