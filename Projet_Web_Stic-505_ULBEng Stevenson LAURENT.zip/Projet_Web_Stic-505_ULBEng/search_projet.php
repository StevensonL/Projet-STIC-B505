<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<table>
    <thead>
        <tr>
            <th> <img src="download.png"> </th>
            <th> <h1> <strong> Nos Projets </strong> </h1> </th>
        </tr>
    </thead>
</table>


<?php

include 'utils.php';

?>


<form method="POST" action="">
    <p>
        <label for="NOM_P">Nom</label>
        <input type="text" id="NOM_P" name="NOM_P"
               value="<?php echoPostValueIfSet('NOM_P'); ?>"/>
    </p>
    <p>
        <label for="MATRICULE_CdPROJET">Charge de projet</label>
        <input type="text" id="MATRICULE_CdPROJET" name="MATRICULE_CdPROJET"
               value="<?php echoPostValueIfSet('MATRICULE_CdPROJET'); ?>"/>
    </p>
    <p>
        <label for="NOM_PRENOM">Charge de projet</label>
        <input type="text" id="NOM_PRENOM" name="NOM_PRENOM"
               value="<?php echoPostValueIfSet('NOM_PRENOM'); ?>"/>
    </p>
    <p>
        <label for="EMAIL">Email</label>
        <input type="email" id="EMAIL" name="EMAIL" placeholder="prenom.nom@ulb.be"
               value="<?php echoPostValueIfSet('EMAIL'); ?>"/>
    </p>
    <p>
        <label for="BAILLEURSFONDS">BAILLEUR</label>
        <input type="text" id="NOM_BAILLEURSFONDS" name="NOM_BAILLEURSFONDS"
         value="<?php echoPostValueIfSet('NOM_BAILLEURSFONDS'); ?>"/>
    </p>
    <p>
        <input type="submit" name="search" value="Chercher">
    </p>
</form>

<?php
if (isset($_POST['search'])) {

    echo '
    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>Projet</th>
                <th>MATRICULE CdProjet</th>
                <th>Nom_Prenom</th>
                <th>Email</th>
                <th>NOM_BAILLEURSFONDS</th>
             </tr>
        </thead>
        <tbody>
    ';

    $nom_p = htmlspecialchars($_POST['NOM_P']);
    $matriculeCdProjet = htmlspecialchars($_POST['MATRICULE_CdPROJET']);
    $nom_prenom = htmlspecialchars($_POST['NOM_PRENOM']);
    $email = htmlspecialchars($_POST['EMAIL']);
    $nom_bailleursfonds = htmlspecialchars($_POST['NOM_BAILLEURSFONDS']);

    $pdo = new PDO("mysql:host:localhost;dbname=asblulbeng;charset=utf8", "root");
    $pdo->query("use asblulbeng");
    $consultQuery = $pdo->prepare("select p.NOM_P, p.MATRICULE_CdProjet, m.NOM_PRENOM, m.EMAIL, b.DENOM_ID
      from Projet p, CdProjet c, bailleursfonds b, Membre m
      where p.MATRICULE_CdPROJET = c.MATRICULE AND p.NOM_BAILLEURSFONDS = b.DENOM_ID"
        . " and (:NOM_P = '' or NOM_P = :NOM_P) "
        . " and (:MATRICULE_CdProjet = '' or MATRICULE_CdProjet = :MATRICULE_CdProjet) "
        . " and (:EMAIL = '' or EMAIL = :EMAIL) "
        . " and (:NOM_BAILLEURSFONDS = '' or NOM_BAILLEURSFONDS  = :NOM_BAILLEURSFONDS) "
     );

    $consultQuery->execute(array(
        ':NOM_P' => $nom_p,
        ':MATRICULE_CdProjet' => $matriculeCdProjet,
        ':NOM_PRENOM' => $nom_prenom,
        ':EMAIL' => $email,
        ':NOM_BAILLEURSFONDS' => $nom_bailleursfonds,
        ));

    $results = $consultQuery->fetchAll();

    if (empty($results)) {
        echo "<tr class='text-center'><td colspan='6'>Pas de résultats</td></tr>";
    }
    foreach ($results as $Projet) {
        echo "<tr>";
            echo "<td>" . $Projet["NOM_P"] . "</td>";
            echo "<td>" . $Projet["MATRICULE_CdProjet"] . "</td>";
            echo "<td>" . $Projet["NOM_PRENOM"] . "</td>";
             echo "<td><a href=\"mailto:" . $Projet["EMAIL"] . "\">" . $Projet["EMAIL"] . "</a></td>";
            echo "<td>" . $Projet["NOM_BAILLEURSFONDS"] . "</td>";
         echo "</tr>";
    }
}
echo '
        </tbody>
    </table>
';
?>

</body>

</html>
