<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<table>
    <thead>
        <tr>
            <th> <img src="download.png"> </th>
            <th> <h1> <strong> Nos Membres </strong> </h1> </th>
        </tr>
    </thead>
</table>


<?php

include 'utils.php';

?>


<form method="POST" action="">
    <p>
        <label for="MATRICULE">Matricule</label>
        <input type="text" id="MATRICULE" name="MATRICULE"
               value="<?php echoPostValueIfSet('MATRICULE'); ?>"/>
    </p>
    <p>
        <label for="NOM_PRENOM">Nom Prenom</label>
        <input type="text" id="NOM_PRENOM" name="NOM_PRENOM"
               value="<?php echoPostValueIfSet('NOM_PRENOM'); ?>"/>
    </p>
    <p>
    <label for="DATE_NAISSANCE">Date de Naissance</label>
        <input type="text" id="DATE_NAISSANCE" name="DATE_NAISSANCE"
         value="<?php echoPostValueIfSet('DATE_NAISSANCE'); ?>"/>
    </p>
    <p>
        <label for="TELEPHONE">Telephone</label>
        <input type="text" id="TELPHONE" name="TELEPHONE"
               value="<?php echoPostValueIfSet('TELEPHONE'); ?>"/>
    </p>
    <p>
    <label for="EMAIL">Email</label>
    <input type="email" id="EMAIL" name="EMAIL" placeholder="prenom.nom@ulb.be"
    value="<?php echoPostValueIfSet('EMAIL'); ?>"/>
    </p>
    <p>
        <label for="DATE_DEBUT">Date de debut</label>
        <input type="text" id="DATE_DEBUT" name="DATE_DEBUT"
               value="<?php echoPostValueIfSet('DATE_DEBUT'); ?>"/>
    </p>
    <p>
        <label for="DATE_FIN">Date de fin</label>
        <input type="text" id="DATE_FIN" name="DATE_FIN"
               value="<?php echoPostValueIfSet('DATE_FIN'); ?>"/>
    </p>
    <p>
        <input type="submit" name="search" value="Chercher">
    </p>
</form>

<?php
if (isset($_POST['search'])) {

    echo '
    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>MATRICULE</th>
                <th>NOM_PRENOM</th>
                <th>DATE_NAISSANCE</th>
                <th>TELEPHONE</th>
                <th>EMAIL</th>   
                <th>DATE_DEBUT</th>            
                <th>DATE_FIN</th>
             </tr>
        </thead>
        <tbody>
    ';

    $matricule = htmlspecialchars($_POST['MATRICULE']);
    $nom_prenom = htmlspecialchars($_POST['NOM_PRENOM']);
    $date_naissance = htmlspecialchars($_POST['DATE_NAISSANCE']);
    $telephone = htmlspecialchars($_POST['TELEPHONE']);
    $email = htmlspecialchars($_POST['EMAIL']);
    $date_debut = htmlspecialchars($_POST['DATE_DEBUT']);
    $date_fin = htmlspecialchars($_POST['DATE_FIN']);

    $pdo = new PDO("mysql:host:localhost;dbname=asblulbeng;charset=utf8", "root");
    $pdo->query("use asblulbeng");
    $consultQuery = $pdo->prepare("select * from membre where "
        . " (:MATRICULE = '' or MATRICULE = :MATRICULE)"
        . " and (:NOM_PRENOM = '' or NOM_PRENOM = :NOM_PRENOM) "
        . " and (:DATE_NAISSANCE = '' or DATE_NAISSANCE = :DATE_NAISSANCE) "
        . " and (:TELEPHONE = '' or TELEPHONE = :TELEPHONE) "
        . " and (:EMAIL = '' or EMAIL = :EMAIL) "
        . " and (:DATE_DEBUT = '' or DATE_DEBUT = :DATE_DEBUT) "
        . " and (:DATE_FIN = '' or DATE_FIN  = :DATE_FIN ) "
    );

    $consultQuery->execute(array(
        ':MATRICULE'=> $matricule,
        ':NOM_PRENOM' => $nom_prenom,
        ':DATE_NAISSANCE' => $date_naissance,
        ':TELEPHONE' => $telephone,
        ':EMAIL' => $email,
        ':DATE_DEBUT' => $date_debut,
        ':DATE_FIN' => $date_fin,
            ));

    $results = $consultQuery->fetchAll();

    if (empty($results)) {
        echo "<tr class='text-center'><td colspan='6'>Pas de résultats</td></tr>";
    }
    foreach ($results as $membre) {
        echo "<tr>";
            echo "<td>" . $membre["MATRICULE"] . "</td>";
            echo "<td>" . $membre["NOM_PRENOM"] . "</td>";
            echo "<td>" . $membre["DATE_NAISSANCE"] . "</td>";
            echo "<td>" . $membre["TELEPHONE"] . "</td>";
            echo "<td>" . $membre["EMAIL"] . "</td>";
            echo "<td>" . $membre["DATE_DEBUT"] . "</td>";
            echo "<td>" . $membre["DATE_FIN"] . "</td>";
         echo "</tr>";
    }
}
echo '
        </tbody>
    </table>
';
?>


</body>

</html>