<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<?php

include 'utils.php';

function checkEmail($email)
{
    $regex = "/^[\w\d\_\.]+@\w+(\.\w+)+$/i";
    return preg_match($regex, $email);
}

?>

<h1>Enregistrer Ecole </h1>

<?php

$bdd = new PDO('mysql:host=localhost;dbname=asblulbeng', 'root');

if (isset($_POST['register'])) {

    $nom_id = trim(htmlspecialchars($_POST['NOM_ID']));
    $adresse = trim(htmlspecialchars($_POST['ADRESSE']));
    $nom_prenom_pdct = trim(htmlspecialchars($_POST['PdCT_NOM_PRENOM']));
    $telephone_pdct = trim(htmlspecialchars($_POST['PdCT_TELEPHONE']));
    $email_pdct = trim(htmlspecialchars($_POST['PdCT_EMAIL']));
    $code_animation = trim(htmlspecialchars($_POST['ANIMATION_NO_DATE']));

    $ok = '';
    $nom_idError = '';
    $adresseError = '';
    $nom_prenom_pdctError = '';
    $telephone_pdctError = '';
    $email_pdctError = '';
    $code_animationError = '';

    if (empty($nom_id)) {
        $nom_idError = 'Requis';
    } else {
        $nom_idLength  = strlen($nom_id);
        if ($nom_idLength < 5 || $nom_idLength > 50 ) {
            $nom_idError = 'Le nom de l"ecole est obligatoire';
        }
    }

    if (empty($adresse)) {
        $adresseError = 'Requis';
    } else {
        $adresseLength = strlen($adresse);
        if ($adresseLength < 5 || $adresseLength > 50) {
            $adresseError = ' Adresse doit contenir entre 5 et 50 caractères';
        }
    }

     if (empty($nom_prenom_pdct)) {
        $nom_prenom_pdctError = 'Requis';
    } else {
        $nom_prenom_pdctLength = strlen($nom_prenom_pdct);
        if ($nom_prenom_pdctLength < 5 || $nom_prenom_pdctLength > 50) {
            $nom_prenom_pdctError = 'Le Nom de la personne de contact est obligatoire';
        }
    }

    if (empty($telephone_pdct)) {
        $telephone_pdctError = 'Requis';
    } else {
        $telephone_pdctLength = strlen($telephone_pdct);
        if ($telephone_pdctLength < 10 || $telephone_pdctLength > 50) {
            $telephone_pdctError = 'Le numero de telephone  est obligatoire';
        }
    }
    if (empty($email_pdct)) {
        $email_pdctError = 'Requis';
    } else if (!checkEmail($email_pdct)) {
        $email_pdctError = 'Email non valide';
    } else {
        $mailExistsQuery = $bdd->prepare("select EMAIL from membre where EMAIL = ?");
        $mailExistsQuery->execute(array($email_pdct));

        if ($mailExistsQuery->rowCount() > 0) {
            $email_pdctError = 'Cet e-mail existe déjà';
        }
    }
    if (empty($code_animation)) {
        $code_animationError = 'Requis';
    } else {
        $code_animationLength = strlen($code_animation);
        if ($code_animationLength < 13 || $code_animationLength > 15) {
            $code_animationError = 'Le code_animation doit contenir entre 13 et 15 caractères';
        }
    }

    if (empty($nom_idError) && empty($adresseError) && empty($nom_prenom_pdctError) 
    && empty($telephone_pdctError) && empty($email_pdctError) && empty($code_animationError) ) {

        $insertQuery = $bdd->prepare("insert into ecole (NOM_ID, ADRESSE, PdCT_NOM_PRENOM, PdCT_TELEPHONE, PdCT_EMAIL, ANIMATION_NO_DATE) values (?, ?, ?, ?, ? ,?)");
        $insertQuery->execute(array($nom_id, $adresse, $nom_prenom_pdct, $telephone_pdct, $email_pdct, $code_animation));
        $ok = "L'animation a bien été enregistré";

    }
}

?>

<form method="POST" action="">
<p>
        <label for="NOM_ID">NOM </label>
        <input type="int" id="NOM_ID" name="NOM_ID" placeholder="NOM_ID"
               value="<?php echoPostValueIfSet('NOM_ID'); ?>"/>
        <?php
        if (!empty($nom_idError)) {
            echo "<span style=\"color: red;\">" . $nom_idError . "</span>";
        }
        ?>
    </p>

    <p>
        <label for="ADRESSE" >Adresse</label>
        <input type="text" id="ADRESSE" name="ADRESSE" placeholder="ADRESSE"
               value="<?php echoPostValueIfSet('ADRESSE'); ?>"/>
        <?php
        if (!empty($adresseError)) {
            echo "<span style=\"color: red;\">" . $adresseError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="PdCT_NOM_PRENOM">Nom Prenom Contact</label>
        <input type="text" id="PdCT_NOM_PRENOM" name="PdCT_NOM_PRENOM" placeholder="PdCT_NOM_PRENOM"
               value="<?php echoPostValueIfSet('PdCT_NOM_PRENOM'); ?>"/>
        <?php
        if (!empty($nom_prenom_pdctError)) {
            echo "<span style=\"color: red;\">" . $nom_prenom_pdctError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="PdCT _TELEPHONE" >Telephone</label>
        <input type="text" id="PdCT_TELEPHONE" name="PdCT_TELEPHONE" placeholder="PdCT_TELEPHONE"
               value="<?php echoPostValueIfSet('PdCT _TELEPHONE'); ?>"/>
        <?php
        if (!empty($telephone_pdctError)) {
            echo "<span style=\"color: red;\">" . $telephone_pdctError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="PdCT _EMAIL" >E-mail</label>
        <input type="text" id="PdCT_EMAIL" name="PdCT_EMAIL"placeholder="PdCT_EMAIL"
               value="<?php echoPostValueIfSet('PdCT _EMAIL'); ?>"/>
        <?php
        if (!empty($email_pdctError)) {
            echo "<span style=\"color: red;\">" . $email_pdctError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="ANIMATION_NO_DATE" >Code Animation</label>
        <input type="text" id="ANIMATION_NO_DATE" name="ANIMATION_NO_DATE" placeholder="ANIMATION_NO_DATE"
               value="<?php echoPostValueIfSet('ANIMATION_NO_DATE'); ?>"/>
        <?php
        if (!empty($code_animationError)) {
            echo "<span style=\"color: red;\">" . $code_animationError . "</span>";
        }
        ?>
    </p>
    </p>
      <p>
        <input type="submit" name="register" value="Enregistrer">
        <input type="reset" name="reset" value="Réinitialiser">
    </p>
</form>

<?php
if (!empty($ok)) {
    echo $ok;
}
?>

</body>
</html>
