<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<img src="download.png">


<table class="table table-striped">
    <thead class="table-dark">
        <tr>
            <th> <a href="consult_recherche.php">Référence </a> </th>
            <th>Nom_Prenom</th>
            <th>Matricule</th>
            <th>Telephone</th>
            <th>Email</th>
            <th>DateDebut</th>
            <th>DateFin</th>
            <th>Projet</th>
        </tr>
    </thead>

    <?php

$pdo = new PDO("mysql:host:localhost;dbname=asblulbeng;charset=utf8", "root");
    $pdo->query("use asblulbeng");
    $consultQuery = $pdo->query(" select * from animation");
       $results = $consultQuery->fetchAll();

    foreach ($results as $animation) {
        echo "<tr>";
            echo "<td>" . $animation["NO_DATE"] . "</td>";
            echo "<td>" . $animation["INTITULE"] . "</td>";
            echo "<td>" . $animation["NOM_PROJET"] . "</td>";
            echo "<td>" . $animation["MATRICULE_CdPROJET"] . "</td>";
            echo "<td>" . $animation["MATRICULE_VOLTR"] . "</td>";
            echo "<td>" . $animation["NOM_ECOLE"] . "</td>";
        echo "</tr>";
    }


    ?>

</table>

<!-- Displaying pop-up that will the list of Membre-->


</body>

</html>
