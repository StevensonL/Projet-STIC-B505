<?php

function echoPostValueIfSet($value)
{
    if (isset($_POST[$value])) {
        echo $_POST[$value];
    }
}

#function echoIfMembreSelected($Membre)
{
    if (isset($_POST['MEMBRE']) && $_POST['MEMBRE'] == $Membre) {
        echo 'selected';
    }
}

#function echoIfProjetSelected($Projet)
{
    if (isset($_POST['PROJET']) && $_POST['PROJET'] == $Projet) {
        echo 'selected';
    }
}

function echoIfIntituleSelected($intitule)
{
    if (isset($_POST['INTITULE']) && $_POST['INTITULE'] == $intitule) {
        echo 'selected';
}
}

#function echoIfAnimationSelected($Animation)
{
    if (isset($_POST['Animation']) && $_POST['Animation'] == $Animation) {
        echo 'selected';
    }
}

?>
