<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<?php

include 'utils.php';

function checkEmail($email)
{
    $regex = "/^[\w\d\_\.]+@\w+(\.\w+)+$/i";
    return preg_match($regex, $email);
}


?>

<h1>Enregistrer Membre </h1>

<?php

$bdd = new PDO('mysql:host=localhost;dbname=asblulbeng', 'root');

if (isset($_POST['register'])) {

    $matricule = trim(htmlspecialchars($_POST['MATRICULE']));
    $nom_prenom = trim(htmlspecialchars($_POST['NOM_PRENOM']));
    $date_naissance = trim(htmlspecialchars($_POST['DATE_NAISSANCE']));
    $telephone = trim(htmlspecialchars($_POST['TELEPHONE']));
    $email = trim(htmlspecialchars($_POST['EMAIL']));
    $date_debut = trim(htmlspecialchars($_POST['DATE_DEBUT']));
    $asbl = trim(htmlspecialchars($_POST['NOM_ASBL']));

    $ok = '';
    $matriculeError = '';
    $nom_prenomError = '';
    $date_naissanceError = '';
    $telephoneError = '';
    $emailError = '';
    $date_debutError = '';
    $asblError = '';

    if (empty($matricule)) {
        $matriculeError = 'Requis';
    } else {
        $matriculeLength  = strlen($matricule);
        if ($matriculeLength < 4 || $matriculeLength> 6 ) {
            $matriculeError = 'Le nom de l"ecole est obligatoire';
        }
    }

    if (empty($nom_prenom)) {
        $nom_prenomError = 'Requis';
    } else {
        $nom_prenomLength = strlen($nom_prenom);
        if ($nom_prenomLength < 5 || $nom_prenomLength > 50) {
            $nom_prenomError = ' Nom & Prenom doit contenir entre 5 et 50 caractères';
        }
    }

     if (empty($date_naissance)) {
        $date_naissanceError = 'Requis';
    } else {
        $date_naissanceLength = strlen($date_naissance);
        if ($date_naissanceLength < 5 || $date_naissanceLength > 50) {
            $date_naissanceError = 'La date de naissance est obligatoire';
        }
    }

    if (empty($telephone)) {
        $telephoneError = 'Requis';
    } else {
        $telephoneLength = strlen($telephone);
        if ($telephoneLength < 10 || $telephoneLength > 50) {
            $telephoneError = 'Le numero de telephone  est obligatoire';
        }
    }

    if (empty($email)) {
        $emailError = 'Requis';
    } else if (!checkEmail($email)) {
        $emailError = 'Email non valide';
    } else {
        $mailExistsQuery = $bdd->prepare("select EMAIL from membre where EMAIL = ?");
        $mailExistsQuery->execute(array($email));

        if ($mailExistsQuery->rowCount() > 0) {
            $emailError = 'Cet e-mail existe déjà';
        }
    }

    if (empty($date_debut)) {
        $date_debutError = 'Requis';
    } else {
        $date_debutLength = strlen($date_debut);
        if ($date_debutLength < 10 || $date_debutLength > 50) {
            $date_debutError = 'La date est obligatoire';
        }
    }
    if (empty($asbl)) {
        $asblError = 'Requis';
    } else {
        $asblLength = strlen($asbl);
        if ($asblLength < 5 || $asblLength > 50) {
            $asblError = 'asbl doit contenir entre 5 et 50 caractères';
        }
    }

    if (empty($matriculeError) && empty($nom_prenom) && empty($date_naissanceError) 
    && empty($telephoneError) && empty($emailError) && empty($date_debutError) && empty($asblError) ) {

        $insertQuery = $bdd->prepare("insert into ecole (MATRICULE, NOM_PRENOM, DATE_NAISSANCE, TELEPHONE, 
                                                    EMAIL, DATE_DEBUT, NOM_ASBL) values (?, ?, ?, ?, ? ,?,?)");
        $insertQuery->execute(array($matricule, $nom_prenom, $date_naissance, $telephone, $email, $date_debut, $asbl));
        $ok = "L'animation a bien été enregistré";

    }
}

?>

<form method="POST" action="">
<p>
        <label for="MATRICULE">Matricule </label>
        <input type="text" id="MATRICULE" name="MATRICULE" placeholder="MATRICULE"
               value="<?php echoPostValueIfSet('MATRICULE'); ?>"/>
        <?php
        if (!empty($matriculeError)) {
            echo "<span style=\"color: red;\">" . $matriculeError . "</span>";
        }
        ?>
    </p>

    <p>
        <label for="NOM_PRENOM" >Nom Prenom</label>
        <input type="text" id="NOM_PRENOM" name="NOM_PRENOM" placeholder="NOM_PRENOM"
               value="<?php echoPostValueIfSet('NOM_PRENOM'); ?>"/>
        <?php
        if (!empty($nom_prenomError)) {
            echo "<span style=\"color: red;\">" . $nom_prenomError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="DATE_NAISSANCE">Date de Naissances</label>
        <input type="text" id="DATE_NAISSANCE" name="DATE_NAISSANCE" placeholder="DATE_NAISSANCE"
               value="<?php echoPostValueIfSet('DATE_NAISSANCE'); ?>"/>
        <?php
        if (!empty($date_naissanceError)) {
            echo "<span style=\"color: red;\">" . $date_naissanceError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="TELEPHONE" >Telephone</label>
        <input type="text" id="TELEPHONE" name="TELEPHONE" placeholder="TELEPHONE"
               value="<?php echoPostValueIfSet('TELEPHONE'); ?>"/>
        <?php
        if (!empty($telephoneError)) {
            echo "<span style=\"color: red;\">" . $telephoneError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="EMAIL" >E-mail</label>
        <input type="text" id="EMAIL" name="EMAIL"placeholder="EMAIL"
               value="<?php echoPostValueIfSet('EMAIL'); ?>"/>
        <?php
        if (!empty($emailError)) {
            echo "<span style=\"color: red;\">" . $emailError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="DATE_DEBUT">Date Inscription</label>
        <input type="text" id="DATE_DEBUT" name="DATE_DEBUT" placeholder="DATE_DEBUT"
               value="<?php echoPostValueIfSet('DATE_DEBUT'); ?>"/>
        <?php
        if (!empty($date_debutError)) {
            echo "<span style=\"color: red;\">" . $date_debutError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="NOM_ASBL" >Asbl</label>
        <input type="text" id="NOM_ASBL" name="NOM_ASBL" placeholder="NOM_ASBL"
               value="<?php echoPostValueIfSet('NOM_ASBL'); ?>"/>
        <?php
        if (!empty($asblError)) {
            echo "<span style=\"color: red;\">" . $asblError . "</span>";
        }
        ?>
    </p>
    </p>
      <p>
        <input type="submit" name="register" value="Enregistrer">
        <input type="reset" name="reset" value="Réinitialiser">
    </p>
</form>

<?php
if (!empty($ok)) {
    echo $ok;
}
?>

</body>
</html>
