<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<?php

include 'utils.php';

?>

<h1>Enregistrer Animation </h1>

<?php

$bdd = new PDO('mysql:host=localhost;dbname=asblulbeng', 'root');

if (isset($_POST['register'])) {

    $no_date = trim(htmlspecialchars($_POST['NO_DATE']));
    $nom_projet = trim(htmlspecialchars($_POST['NOM_PROJET']));
    $matricule_cdprojet = trim(htmlspecialchars($_POST['MATRICULE_CdPROJET']));
    $matricule_voltr = trim(htmlspecialchars($_POST['MATRICULE_VOLTR']));
    $nom_ecole = trim(htmlspecialchars($_POST['NOM_ECOLE']));
    $intitule = trim(htmlspecialchars($_POST['INTITULE']));

    $ok = '';
    $no_dateError = '';
    $nom_projetError = '';
    $matricule_cdpError = '';
    $matricule_voltrError = '';
    $nom_ecoleError = '';
    $intituleError = '';

    if (empty($no_date)) {
        $no_dateError = 'Requis';
    } else {
        $no_dateLength  = strlen($no_date);
        if ($no_dateLength < 13 || $no_dateLength > 15 ) {
            $no_dateError = 'Le no_date est obligatoire';
        }
    }

    if (empty($nom_projet)) {
        $nom_projetError = 'Requis';
    } else {
        $nom_projetLength = strlen($nom_projet);
        if ($nom_projetLength < 3 || $nom_projetLength > 50) {
            $nom_projetError = 'Le nom du projet doit contenir entre 3 et 50 caractères';
        }
    }

     if (empty($matricule_cdprojet)) {
        $matricule_cdprojetError = 'Requis';
    } else {
        $matricule_cdprojetLength = strlen($matricule_cdprojet);
        if ($matricule_cdprojetLength < 5 || $matricule_cdprojetLength > 7) {
            $matricule_cdprojetError = 'Le Matricule du charge de projet est obligatoire';
        }
    }

    if (empty($matricule_voltr)) {
        $matricule_voltrError = 'Requis';
    } else {
        $matricule_voltrLength = strlen($matricule_voltr);
        if ($matricule_voltrLength < 5 || $matricule_voltrLength > 7) {
            $matricule_voltrError = 'Le Matricule du volontaire  est obligatoire';
        }
    }

    if (empty($nom_ecole)) {
        $nom_ecoleError = 'Requis';
    } else {
        $nom_ecoleLength = strlen($nom_ecole);
        if ($nom_ecoleLength < 5 || $nom_ecoleLength > 50) {
            $nom_ecoleError = 'Le nom_ecole doit contenir entre 5 et 50 caractères';
        }
    }

    if (empty($intitule)) {
        $intituleError = 'Requis';
    } else {
        $intituleLength = strlen($intitule);
        if ($intituleLength < 5 || $intituleLength > 50) {
            $intituleError = 'L intitule doit contenir entre 5 et 50 caractères';
        }
    }

    if (empty($no_dateError) && empty($nom_projetError) && empty($matricule_cdprojetError) 
    && empty($matricule_voltrError) && empty($nom_ecoleError) && empty($intituleError) ) {

        $insertQuery = $bdd->prepare("insert into animation (NO_DATE, NOM_PROJET, MATRICULE_CdPROJET, MATRICULE_VOLTR, NOM_ECOLE, INTITULE) values (?, ?, ?, ?, ? ,?)");
        $insertQuery->execute(array($no_date, $nom_projet, $matricule_cdprojet, $matricule_voltr, $nom_ecole, $intitule));
        $ok = "L'animation a bien été enregistré";

    }
}

?>

<form method="POST" action="">
<p>
        <label for="NO_DATE">NO_DATE </label>
        <input type="int" id="NO_DATE" name="NO_DATE" placeholder="NO_DATE"
               value="<?php echoPostValueIfSet('NO_DATE'); ?>"/>
        <?php
        if (!empty($no_dateError)) {
            echo "<span style=\"color: red;\">" . $no_dateError . "</span>";
        }
        ?>
    </p>

    <p>
        <label for="NOM_PROJET" >PROJET</label>
        <input type="text" id="NOM_PROJET" name="NOM_PROJET" placeholder="NOM_PROJET"
               value="<?php echoPostValueIfSet('NOM_PROJET'); ?>"/>
        <?php
        if (!empty($nom_projetError)) {
            echo "<span style=\"color: red;\">" . $nom_projetError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="MATRICULE_CdPROJET">CdPRPOJET</label>
        <input type="text" id="MATRICULE_CdPROJET" name="MATRICULE_CdPROJET" placeholder="MATRICULE_CdPROJET"
               value="<?php echoPostValueIfSet('MATRICULE_CdPROJET'); ?>"/>
        <?php
        if (!empty($matricule_cdprojetError)) {
            echo "<span style=\"color: red;\">" . $matricule_cdprojetError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="MATRICULE_VOLTR" >VOLONTAIRE</label>
        <input type="text" id="VOLONTAIRES" name="MATRICULE_VOLTR" placeholder="MATRICULE_VOLTR"
               value="<?php echoPostValueIfSet('MATRICULE_VOLTR'); ?>"/>
        <?php
        if (!empty($matricule_voltrError)) {
            echo "<span style=\"color: red;\">" . $matricule_voltrError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="NOM_ECOLE" >ECOLE</label>
        <input type="text" id="NOM_ECOLE" name="NOM_ECOLE"placeholder="NOM_ECOLE"
               value="<?php echoPostValueIfSet('NOM_ECOLE'); ?>"/>
        <?php
        if (!empty($nom_ecoleError)) {
            echo "<span style=\"color: red;\">" . $nom_ecoleError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="intitule">INTITULE</label>
        <select id="text" name="INTITULE" > 
            <option></option>
            <option <?php echoIfIntituleSelected("ENVAHIR"); ?> value="ENVAHIR">Ils vont nous envahir</option>
            <option <?php echoIfIntituleSelected("ISLAM"); ?> value="ISLAM">Ils vont islamiser l'europe</option>
            <option <?php echoIfIntituleSelected("DROIT"); ?> value="DROIT">Ils n'ont pas le droit d'etre la!</option>
        </select>
        <?php
        if (!empty($intituleError)) {
            echo "<span style=\"color: red;\">" . $intituleError . "</span>";
        }
        ?>
    </p>
      <p>
        <input type="submit" name="register" value="Enregistrer">
        <input type="reset" name="reset" value="Réinitialiser">
    </p>
</form>

<?php
if (!empty($ok)) {
    echo $ok;
}
?>

</body>
</html>
