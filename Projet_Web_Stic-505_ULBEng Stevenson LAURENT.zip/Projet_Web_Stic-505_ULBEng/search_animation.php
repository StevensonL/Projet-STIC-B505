<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<table>
    <thead>
        <tr>
            <th> <img src="download.png"> </th>
            <th> <h1> <strong> Nos Animations </strong> </h1> </th>
        </tr>
    </thead>
</table>


<?php

include 'utils.php';

?>

<form method="POST" action="">
    <p>
        <label for="NO_DATE">Code</label>
        <input type="text" id="NO_DATE" name="NO_DATE"
               value="<?php echoPostValueIfSet('NO_DATE'); ?>"/>
    </p>
    <p>
        <label for="INTITULE">Intitule</label>
        <input type="text" id="INTITULE" name="INTITULE"
               value="<?php echoPostValueIfSet('INTITULE'); ?>"/>
    </p>
    <p>
    <label for="NOM_PROJET">Projet</label>
        <input type="text" id="NOM_PROJET" name="NOM_PROJET"
         value="<?php echoPostValueIfSet('NOM_PROJET'); ?>"/>
    </p>
    <p>
        <label for="MATRICULE_CdPROJET">Coordonateur</label>
        <input type="text" id="MATRICULE_CdPROJET" name="MATRICULE_CdPROJET"
               value="<?php echoPostValueIfSet('MATRICULE_CdPROJET'); ?>"/>
    </p>
    <p>
        <label for="MATRICULE_VOLTR">Volontaire</label>
        <input type="text" id="MATRICULE_VOLTR" name="MATRICULE_VOLTR"
               value="<?php echoPostValueIfSet('MATRICULE_VOLTR'); ?>"/>
    </p>
    <p>
        <label for="NOM_ECOLE">Ecole</label>
        <input type="text" id="NOM_ECOLE" name="NOM_ECOLE"
               value="<?php echoPostValueIfSet('NOM_ECOLE'); ?>"/>
    </p>
    <p>
        <input type="submit" name="search" value="Chercher">
    </p>
</form>

<?php
if (isset($_POST['search'])) {

    echo '
    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>NO_DATE</th>
                <th>INTITULE</th>
                <th>NOM_PROJET</th>
                <th>MATRICULE_CdProjet</th>
                <th>MATRICULE_VOLTR</th>
                <th>NOM_ECOLE</th>
             </tr>
        </thead>
        <tbody>
    ';

    $no_date = htmlspecialchars($_POST['NO_DATE']);
    $intitule = htmlspecialchars($_POST['INTITULE']);
    $non_projet = htmlspecialchars($_POST['NOM_PROJET']);
    $matriculeCdProjet = htmlspecialchars($_POST['MATRICULE_CdPROJET']);
    $matriculeVoltr = htmlspecialchars($_POST['MATRICULE_VOLTR']);
    $nom_ecole = htmlspecialchars($_POST['NOM_ECOLE']);

    $pdo = new PDO("mysql:host:localhost;dbname=asblulbeng;charset=utf8", "root");
    $pdo->query("use asblulbeng");
    $consultQuery = $pdo->prepare("select * from animation where "
        . " (:NO_DATE = '' or NO_DATE = :NO_DATE) "
        . " and (:INTITULE = '' or INTITULE = :INTITULE) "
        . " and (:NOM_PROJET = '' or NOM_PROJET = :NOM_PROJET) "
        . " and (:MATRICULE_CdProjet = '' or MATRICULE_CdProjet = :MATRICULE_CdProjet) "
        . " and (:MATRICULE_VOLTR = '' or MATRICULE_VOLTR = :MATRICULE_VOLTR) "
        . " and (:NOM_ECOLE = '' or NOM_ECOLE  = :NOM_ECOLE) "
    );

    $consultQuery->execute(array(
        ':NO_DATE' => $no_date,
        ':INTITULE' => $intitule,
        ':NOM_PROJET' => $non_projet,
        ':MATRICULE_CdPROJET' => $matriculeCdProjet,
        ':MATRICULE_VOLTR' => $matriculeVoltr,
        ':NOM_ECOLE' => $nom_ecole,
    ));

    $results = $consultQuery->fetchAll();

    if (empty($results)) {
        echo "<tr class='text-center'><td colspan='6'>Pas de résultats</td></tr>";
    }
    foreach ($results as $animation) {
        echo "<tr>";
            echo "<td>" . $animation["NO_DATE"] . "</td>";
            echo "<td>" . $animation["INTITULE"] . "</td>";
            echo "<td>" . $animation["NOM_PROJET"] . "</td>";
            echo "<td>" . $animation["MATRICULE_CdPROJET"] . "</td>";
            echo "<td>" . $animation["MATRICULE_VOLTR"] . "</td>";
            echo "<td>" . $animation["NOM_ECOLE"] . "</td>";
         echo "</tr>";
    }
}
echo '
        </tbody>
    </table>
';
?>


</body>

</html>
