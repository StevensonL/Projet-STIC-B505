<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <title>ASBL ULB Engagee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="myp.css">
</head>

<body>

<nav>
    <ul>
    <li class="menu_Nos chiffres"><a href="#">Reports</a>
            <ul class="submenu">
                <li><a href="Nos chiffres_projet.php">Projet</a></li>
                <li><a href="Nos chiffres_animation.php">Animation</a></li>
            </ul>
        </li>
        <li class ="menu_Register"><a href="#">Register</a>
            <ul class="submenu">
                <li><a href="register_inscription_volontaire.php">InscriptionVolontaire</a></li>
                <li><a href="register_animation.php">Animation</a></li>
                <li><a href="register_membre.php">Membre</a></li>
                <li><a href="register_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_recherche"><a href="#">Recherche</a>
            <ul class="submenu">
                <li><a href="search_projet.php">Projet</a></li>
                <li><a href="search_animation.php">Animation</a></li>
                <li><a href="search_membre.php">Membre</a></li>
             </ul>
        </li>
        <li class="menu_consultation"><a href="#">Consultation</a>
            <ul class="submenu">
                <li><a href="consult_projet.php">Projet</a></li>
                <li><a href="consult_animation.php">Animation</a></li>
                <li><a href="consult_membre.php">Membre</a></li>
                <li><a href="consult_ecole.php">Ecole</a></li>
            </ul>
        </li>
        <li class="menu_accueil"><a href="accueil.php">Accueil</a> </li>
</nav>

<?php

include 'utils.php';

function checkEmail($email)
{
    $regex = "/^[\w\d\_\.]+@\w+(\.\w+)+$/i";
    return preg_match($regex, $email);
}


?>

<h1> Inscription Volontaire </h1>

<?php

$bdd = new PDO('mysql:host=localhost;dbname=asblulbeng', 'root');

if (isset($_POST['register'])) {

    $nom_prenom = trim(htmlspecialchars($_POST['NOM_PRENOM']));
    $telephone = trim(htmlspecialchars($_POST['TELEPHONE']));
    $email = trim(htmlspecialchars($_POST['EMAIL']));
    $org_univ = trim(htmlspecialchars($_POST['ORG_UNIV']));

    $ok = '';
    $nom_prenomError = '';
    $telephoneError = '';
    $emailError = '';
    $org_univError = '';

    if (empty($nom_prenom)) {
        $nom_prenomError = 'Requis';
    } else {
        $nom_prenomLength = strlen($nom_prenom);
        if ($nom_prenomLength < 5 || $nom_prenomLength > 50) {
            $nom_prenomError = ' Nom & Prenom doit contenir entre 5 et 50 caractères';
        }
    }

    if (empty($telephone)) {
        $telephoneError = 'Requis';
    } else {
        $telephoneLength = strlen($telephone);
        if ($telephoneLength < 8 || $telephoneLength > 50) {
            $telephoneError = 'Le numero de telephone  est obligatoire';
        }
    }

    if (empty($email)) {
        $emailError = 'Requis';
    } else if (!checkEmail($email)) {
        $emailError = 'Email non valide';
    } else {
        $mailExistsQuery = $bdd->prepare("select EMAIL from membre where EMAIL = ?");
        $mailExistsQuery->execute(array($email));

        if ($mailExistsQuery->rowCount() > 0) {
            $emailError = 'Cet e-mail existe déjà';
        }
    }

    if (empty($org_univ)) {
        $org_univError = 'Requis';
    } else {
        $org_univLength = strlen($org_univ);
        if ($org_univLength < 3 || $org_univLength> 50) {
            $org_univError = 'Organisation ou universite doit contenir entre 3 et 50 caractères';
        }
    }

    if (empty($nom_prenomError) && empty($telephoneError) && empty($emailError)  && empty($org_univError) ) {

        $insertQuery = $bdd->prepare("insert into voltr_inscription (NOM_PRENOM, TELEPHONE, EMAIL, ORG_UNIV) values ( ?, ?, ?, ?)");
        $insertQuery->execute(array($nom_prenom, $telephone, $email, $org_univ));
        $ok = "Les informations ont bien été enregistré Merci!!!";

    }
}

?>

<form method="POST" action="">

    <p>
        <label for="NOM_PRENOM" >Nom Prenom</label>
        <input type="text" id="NOM_PRENOM" name="NOM_PRENOM" placeholder="NOM_PRENOM"
               value="<?php echoPostValueIfSet('NOM_PRENOM'); ?>"/>
        <?php
        if (!empty($nom_prenomError)) {
            echo "<span style=\"color: red;\">" . $nom_prenomError . "</span>";
        }
        ?>
    </p>

    <p>
        <label for="TELEPHONE" >Telephone</label>
        <input type="text" id="TELEPHONE" name="TELEPHONE" placeholder="TELEPHONE"
               value="<?php echoPostValueIfSet('TELEPHONE'); ?>"/>
        <?php
        if (!empty($telephoneError)) {
            echo "<span style=\"color: red;\">" . $telephoneError . "</span>";
        }
        ?>
    </p>
    <p>
        <label for="EMAIL" >E-mail</label>
        <input type="text" id="EMAIL" name="EMAIL"placeholder="EMAIL"
               value="<?php echoPostValueIfSet('EMAIL'); ?>"/>
        <?php
        if (!empty($emailError)) {
            echo "<span style=\"color: red;\">" . $emailError . "</span>";
        }
        ?>
    </p>

    <p>
        <label for="ORG_UNIV" >Asbl</label>
        <input type="text" id="ORG_UNIV" name="ORG_UNIV" placeholder="ORG_UNIV"
               value="<?php echoPostValueIfSet('ORG_UNIV'); ?>"/>
        <?php
        if (!empty($org_univError)) {
            echo "<span style=\"color: red;\">" . $org_univError . "</span>";
        }
        ?>
    </p>
    </p>
      <p>
        <input type="submit" name="register" value="Enregistrer">
        <input type="reset" name="reset" value="Réinitialiser">
    </p>
</form>

<?php
if (!empty($ok)) {
    echo $ok;
}
?>

</body>
</html>
